<?php

// see README.md for an explanation of these config params
/*$TWILIO_ACCOUNT_SID = 'your account sid here';
$TWILIO_IPM_SERVICE_SID = 'your service sid here';
$TWILIO_API_KEY = 'your API key here';
$TWILIO_API_SECRET = 'your API secret here';*/

$TWILIO_ACCOUNT_SID = 'ACe1065454a067c5aaed51d03b39f90faf';
$TWILIO_IPM_SERVICE_SID = 'ISe37800e946eb46af9da5a36bc2f17dde';
$TWILIO_API_KEY = 'SK9ff1b5e3168b3afb20af3d5f64e2d5bb';
$TWILIO_API_SECRET = 'izMNavzaejEJfBQChaCqztF7LQZ8OGQo';
?>