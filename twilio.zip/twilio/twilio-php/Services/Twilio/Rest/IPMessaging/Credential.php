<?php

class Services_Twilio_Rest_IPMessaging_Credential extends Services_Twilio_IPMessagingInstanceResource {

}
